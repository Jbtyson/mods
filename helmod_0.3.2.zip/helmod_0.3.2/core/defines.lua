helmod_defines = {}

helmod_icons = {}
helmod_icons["unknown-assembling-machine"]="__helmod__/graphics/icons/unknown-assembling-machine.png"
helmod_icons["default-assembling-machine"]="__helmod__/graphics/icons/unknown-assembling-machine.png"

helmod_display_sizes = {"1920x1200","1920x1080","1680x1050","1680x900","1440x900","1360x768"}

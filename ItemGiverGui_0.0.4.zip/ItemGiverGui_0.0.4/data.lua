data:extend({
  {
    type = "custom-input",
    name = "igg-toggle",
    key_sequence = "SHIFT + ENTER",
    consuming = "script-only"
  }
})

require("prototypes.styles")
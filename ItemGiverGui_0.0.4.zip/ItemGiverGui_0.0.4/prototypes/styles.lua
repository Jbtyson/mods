data.raw["gui-style"]["default"]["igg-scroll-pane"] =
{
  type = "scroll_pane_style",
  maximal_height = 472,
  maximal_width = 590
}
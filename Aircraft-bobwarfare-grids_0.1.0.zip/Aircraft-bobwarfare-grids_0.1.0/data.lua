data.raw["car"]["cargo-plane"].equipment_grid = "bob-car"
data.raw["car"]["gunship"].equipment_grid = "bob-tank-2"
data.raw["car"]["jet"].equipment_grid = "bob-tank-2"
data.raw["car"]["flying-fortress"].equipment_grid = "power-armor-equipment-grid-mk3"

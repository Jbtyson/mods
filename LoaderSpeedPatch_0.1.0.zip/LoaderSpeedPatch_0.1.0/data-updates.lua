--log("[LSP] patching loaders")
for k, entity in pairs(data.raw["loader"]) do
  if entity.name == "loader" then
    --log("[LSP] patching loaders")
    entity.speed = 0.038 -- default 0.03125
  elseif entity.name == "fast-loader" then
    --log("[LSP] patching fast loaders")
    entity.speed = 0.0704 -- default 0.0625
  elseif entity.name == "express-loader" then
    --log("[LSP] patching express loaders")
    entity.speed = 0.106 -- default 0.09375
  end

end

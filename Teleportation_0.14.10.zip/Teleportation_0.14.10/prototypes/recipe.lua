data:extend({
	{
		type = "recipe",
		name = "teleportation-beacon",
		enabled = false,
		ingredients =
		{
			{"steel-plate", 100},
			{"copper-plate", 100},
			{"advanced-circuit", 100},
			{"alien-artifact", 20}
		},
		result = "teleportation-beacon",
    energy_required = 5
	},
	{
		type = "recipe",
		name = "teleportation-equipment",
		enabled = false,
		energy_required = 10,
		ingredients = 
		{
			{"teleportation-beacon", 1},
			{"rocket-control-unit", 100},
			{"low-density-structure", 50},
			{"fusion-reactor-equipment", 30}
		},
		result = "teleportation-equipment",
	},
  {
    type = "recipe",
    name = "teleportation-portal",
    enabled = false,
    ingredients = {
      {"fusion-reactor-equipment", 1},
      {"alien-artifact", 100}
    },
    result = "teleportation-portal",
    energy_required = 30
  },
	--[[{
		type = "recipe",
		name = "teleportation-telesender",
		enabled = false,
		ingredients =
		{
			{"teleportation-beacon", 1},
			{"advanced-circuit", 100},
			{"alien-artifact", 100}
		},
		result = "teleportation-telesender",
    energy_required = 5
	}]]
})
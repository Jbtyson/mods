data:extend(
{
  {
    type = "technology",
    name = "recursive-blueprints",
    icon = "__recursive-blueprints__/graphics/recursive-blueprints-technology.png",
    icon_size = 128,
    effects =
    {
      {type = "unlock-recipe", recipe = "blueprint-deployer" },
      {type = "unlock-recipe", recipe = "blueprint-printer" },
      {type = "unlock-recipe", recipe = "blueprint-digitizer" },
      {type = "unlock-recipe", recipe = "clone-blueprint" },
      {type = "unlock-recipe", recipe = "wipe-blueprint" },
      {type = "unlock-recipe", recipe = "insert-blueprint" },
      {type = "unlock-recipe", recipe = "extract-blueprint" },


    },
    prerequisites = {"logistic-system"},
    unit = {
      count = 250,
      ingredients = {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 30
    },
    order = "c-k-d",
  },
}
)
data:extend({
 {
    type = "recipe",
    name = "lighted-small-electric-pole",
    enabled = "false",
    ingredients = 
    {
      {"small-electric-pole", 1},
      {"small-lamp",1}
    },
    result = "lighted-small-electric-pole"
  },
   {
    type = "recipe",
    name = "lighted-medium-electric-pole",
    enabled = "false",
    ingredients = 
    {
      {"medium-electric-pole", 1},
      {"small-lamp",1}
    },
    result = "lighted-medium-electric-pole"
  },
  {
    type = "recipe",
    name = "lighted-big-electric-pole",
    enabled = "false",
    ingredients = 
    {
      {"big-electric-pole", 1},
      {"small-lamp",1}
    },
    result = "lighted-big-electric-pole"
  },
    {
    type = "recipe",
    name = "lighted-substation",
    enabled = "false",
    ingredients = 
    {
      {"substation", 1},
      {"small-lamp",1}
    },
    result = "lighted-substation"
  }
})
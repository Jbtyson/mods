if data.raw.technology["tungsten-processing"] then
  bobmods.lib.tech.add_prerequisite ("flying-fortress", "tungsten-alloy-processing")
end
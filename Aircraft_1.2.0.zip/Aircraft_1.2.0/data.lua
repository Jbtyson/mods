require("prototypes.entities")
require("prototypes.items")
require("prototypes.recipes")
require("prototypes.technologies")
require("prototypes.equipment-grid")
require("prototypes.equipment")
require("prototypes.recipe-updates") --Bob's mods recipe replacements
require("prototypes.technologies-updates") --Bob's mods tech replacements